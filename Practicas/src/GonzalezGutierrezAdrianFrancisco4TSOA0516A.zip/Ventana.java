/*  Adrian Francisco Gonzalez Gutierrez
 *  Seccion D05
 *  Tarea 4 
 * */
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.TextArea;
import java.awt.TextField;

public class Ventana extends Frame {
	private TextField campo;
	private TextArea area;
	private Button boton;
	
	public Ventana(){
		campo = new TextField();
		area = new TextArea();
		boton = new Button("Mi boton");
		area.setEnabled(false);
		setSize(500,500);
		setLayout(new BorderLayout());
		add("North",campo);
		add("Center",area);
		add("South",boton);
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ventana v = new Ventana();
		v.setVisible(true);
	}

}
