package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

public interface ServidorNombresListener {
	void listUpdated(ServidorNombresEvent evt);
}
